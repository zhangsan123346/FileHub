#pragma once

namespace ffi {
    extern "C" {
        void start_app();
    }
}

