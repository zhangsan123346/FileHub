#include "bindings/bindings.h"

int main(int argc, char * argv[]) {
	ffi::start_app();
	return 0;
}
