package com.tauri.api

class MainActivity : TauriActivity()