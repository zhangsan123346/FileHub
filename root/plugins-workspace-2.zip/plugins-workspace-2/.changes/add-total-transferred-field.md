---
"upload": "minor"
"upload-js": "minor"
---

Added a new field `progressTotal` to track the total amount of data transferred during the upload/download process.
