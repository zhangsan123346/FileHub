---
"fs": "patch"
"fs-js": "patch"
---

Fix `readDir` function failing to read directories that contain broken symlinks.

