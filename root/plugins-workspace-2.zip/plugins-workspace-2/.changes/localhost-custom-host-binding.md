---
'localhost': 'minor'
---

Add custom host binding to allow external access