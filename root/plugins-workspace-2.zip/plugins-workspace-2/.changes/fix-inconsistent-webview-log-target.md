---
'log-plugin': 'patch'
'log-js': 'patch'
---

Make webview log target more consistent that it always starts with `webview`
