---
deep-link: patch
deep-link-js: patch
---

`onOpenUrl()` will now not call `getCurrent()` anymore, matching the documented behavior.
