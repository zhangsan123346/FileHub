---
"sql": "patch"
---

Allow blocking on async code without creating a nested runtime.
