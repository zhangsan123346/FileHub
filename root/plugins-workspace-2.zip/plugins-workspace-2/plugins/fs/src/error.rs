// Copyright 2019-2023 Tauri Programme within The Commons Conservancy
// SPDX-License-Identifier: Apache-2.0
// SPDX-License-Identifier: MIT

use std::path::PathBuf;

use serde::{Serialize, Serializer};

#[derive(Debug, thiserror::Error)]
#[non_exhaustive]
pub enum Error {
    #[error(transparent)]
    Json(#[from] serde_json::Error),
    #[error(transparent)]
    Tauri(#[from] tauri::Error),
    #[error(transparent)]
    Io(#[from] std::io::Error),
    #[error("forbidden path: {0}")]
    PathForbidden(PathBuf),
    /// Invalid glob pattern.
    #[error("invalid glob pattern: {0}")]
    GlobPattern(#[from] glob::PatternError),
    /// Watcher error.
    #[cfg(feature = "watch")]
    #[error(transparent)]
    Watch(#[from] notify::Error),
    #[cfg(target_os = "android")]
    #[error(transparent)]
    PluginInvoke(#[from] tauri::plugin::mobile::PluginInvokeError),
    #[error("URL is not a valid path")]
    InvalidPathUrl,
    #[error("Unsafe PathBuf: {0}")]
    UnsafePathBuf(&'static str),
}

impl Serialize for Error {
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}
