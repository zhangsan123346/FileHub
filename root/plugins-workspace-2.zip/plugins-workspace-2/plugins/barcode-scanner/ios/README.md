# Tauri Plugin Barcode Scanner

A description of this package.
